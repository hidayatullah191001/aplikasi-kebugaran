            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <footer class="footer text-center">
               Copyright &copy Aplikasi Tes Kebugaran <?= date('Y') ?>  
            </footer>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="<?=base_url('assets/') ?>assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="<?=base_url('assets/') ?>assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="<?=base_url('assets/') ?>assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="<?=base_url('assets/') ?>dist/js/app-style-switcher.js"></script>
    <!--Wave Effects -->
    <script src="<?=base_url('assets/') ?>dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="<?=base_url('assets/') ?>dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="<?=base_url('assets/') ?>dist/js/custom.js"></script>
    <!--This page JavaScript -->
    <!--chartis chart-->
    <script src="<?=base_url('assets/') ?>assets/libs/chartist/dist/chartist.min.js"></script>
    <script src="<?=base_url('assets/') ?>assets/libs/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="<?=base_url('assets/') ?>dist/js/pages/dashboards/dashboard1.js"></script>
</body>

</html>